from __future__ import annotations
import streamlit as st
import pandas as pd
from core import state
from core.market import to_float, vlookup, fetch_moex_forts, fetch_moex_ims
from core.config import TREND_VALUES, MARGIN_COL_MAP
from core.calc import get_instrument
from ui.theme import format_date

def update_active_tickers():
    sel = st.session_state.get("picker_ms", [])
    manual = [x.strip().upper() for x in st.session_state.get("picker_txt", "").split(",") if x.strip()]
    state.set_active_tickers(sel + manual)
    state.autosave(force=True)

def render_main_tab(*, api_df, go_df, md_df, iss_df, ims_df=None, deposit, margin_type, mobile=False):
    st.subheader("Данные с биржи")

    if not iss_df.empty and "SECID" in iss_df.columns:
        # ИСПРАВЛЕНО: приводим SECID к верхнему регистру для выпадающего списка
        active_iss = iss_df[iss_df["VALTODAY"].fillna(0) > 0] if "VALTODAY" in iss_df.columns else iss_df
        available_tickers = sorted(active_iss["SECID"].dropna().astype(str).str.upper().unique().tolist())
    else:
        available_tickers = []

    active = state.active_tickers()

    if "picker_ms" not in st.session_state:
        st.session_state["picker_ms"] = [t for t in active if t in available_tickers]
    if "picker_txt" not in st.session_state:
        manual = [t for t in active if t not in available_tickers]
        st.session_state["picker_txt"] = ", ".join(manual)

    st.markdown("#### Выбор инструментов")
    c1, c2 = st.columns([3, 2])
    with c1:
        st.multiselect(
            "Выбрать из списка MOEX ISS",
            options=available_tickers,
            key="picker_ms",
            on_change=update_active_tickers,
            help="Нажмите на крестик рядом с тикером, чтобы удалить его"
        )
    with c2:
        st.text_input("Ввести тикер вручную (через запятую)", key="picker_txt", on_change=update_active_tickers)

    picked = state.active_tickers()
    if not picked:
        st.info("Выберите хотя бы один тикер для отображения данных.")
        return

    # === ОДИН ПРОХОД: собираем данные по всем тикерам ===
    instruments = {}
    missing_in_iss = []
    for t in picked:
        inst = get_instrument(t, iss_df=iss_df, go_df=go_df, api_df=api_df, md_df=md_df, ims_df=ims_df, margin_type=margin_type)
        instruments[t] = inst
        # ИСПРАВЛЕНО: проверка наличия тикера в ISS без учета регистра
        if not iss_df.empty and "SECID" in iss_df.columns and t.upper() not in iss_df["SECID"].astype(str).str.upper().values:
            missing_in_iss.append(t)

    # === 1. НАСТРОЙКА ТРЕНДОВ ===
    with st.expander("Настройка параметров рынка (Тренд, Волна, Тенденция)", expanded=False):
        rows = []
        for t in picked:
            inst = instruments[t]
            margin_go = min(inst.margin_long, inst.margin_short) if inst.margin_long > 0 and inst.margin_short > 0 else max(inst.margin_long, inst.margin_short)
            max_contracts = int(deposit // margin_go) if margin_go > 0 else 0
            risk_pct = round(margin_go / deposit * 100, 2) if margin_go > 0 and deposit > 0 else 0.0

            m = state.ticker(t)["market"]
            rows.append({
                "Тикер": t,
                "Наименование": inst.name,
                "ГО": margin_go,
                "Доступно": max_contracts,
                "Риск, %": risk_pct,
                "Тренд": m["trend"],
                "Волна": m["wave"],
                "Тенденция": m["tendency"],
            })

        df = pd.DataFrame(rows)
        edited_df = st.data_editor(
            df, use_container_width=True, hide_index=True,
            column_config={
                "Тренд": st.column_config.SelectboxColumn("Тренд", options=TREND_VALUES, required=True),
                "Волна": st.column_config.SelectboxColumn("Волна", options=TREND_VALUES, required=True),
                "Тенденция": st.column_config.SelectboxColumn("Тенденция", options=TREND_VALUES, required=True),
                "ГО": st.column_config.NumberColumn(format="%.2f ₽"),
                "Риск, %": st.column_config.ProgressColumn(format="%.2f%%", min_value=0, max_value=100),
            },
            disabled=["Тикер", "Наименование", "ГО", "Доступно", "Риск, %"],
            key="main_table_editor"
        )

        for _, row in edited_df.iterrows():
            state.ticker(row["Тикер"])["market"].update({"trend": row["Тренд"], "wave": row["Волна"], "tendency": row["Тенденция"]})
        state.autosave()

    # === 2. ТАБЛИЦА РЫНОЧНЫХ ДАННЫХ ===
    st.markdown("#### Рыночные данные")

    if st.button("Обновить данные таблицы", key="refresh_market_table"):
        fetch_moex_forts.clear()
        fetch_moex_ims.clear()
        st.rerun()

    rows = []
    for t in picked:
        inst = instruments[t]
        margin_long = inst.margin_long
        margin_short = inst.margin_short
        margin_go = min(margin_long, margin_short) if margin_long > 0 and margin_short > 0 else max(margin_long, margin_short)
        max_contracts = int(deposit // margin_go) if margin_go > 0 else 0
        dec = inst.decimals

        def fmt_val(val, d): return f"{val:,.{d}f}".replace(",", " ").replace(".", ",") if pd.notna(val) else "-"
        def fmt_money(val): return f"{val:,.2f}".replace(",", " ").replace(".", ",") + " ₽" if pd.notna(val) else "-"
        def fmt_int(val): return f"{val:,.0f}".replace(",", " ") if pd.notna(val) else "-"

        rows.append({
            "Код контракта": inst.asset_code,
            "Наименование контракта": inst.name,
            "Тикер": t,
            "Шаг цены": fmt_val(inst.min_step, dec),
            "Стоимость шага цены": fmt_val(inst.step_price, dec),
            "ГО покупатель": fmt_money(margin_long),
            "ГО продавец": fmt_money(margin_short),
            "Всего контрактов доступно": fmt_int(max_contracts),
            "Рыночная цена": fmt_val(inst.price, dec),
            "Свободно для сделок": "—",
            "Дата экспирации": format_date(inst.expiry),
        })

    table_df = pd.DataFrame(rows)

    st.dataframe(
        table_df,
        use_container_width=True,
        hide_index=True,
        column_config={
            "Код контракта": st.column_config.TextColumn(width="small"),
            "Наименование контракта": st.column_config.TextColumn(width="medium"),
            "Тикер": st.column_config.TextColumn(width="small"),
            "Шаг цены": st.column_config.TextColumn(width="small"),
            "Стоимость шага цены": st.column_config.TextColumn(width="small"),
            "ГО покупатель": st.column_config.TextColumn(width="small"),
            "ГО продавец": st.column_config.TextColumn(width="small"),
            "Всего контрактов доступно": st.column_config.TextColumn(width="small"),
            "Рыночная цена": st.column_config.TextColumn(width="small"),
            "Свободно для сделок": st.column_config.TextColumn(width="small"),
            "Дата экспирации": st.column_config.TextColumn(width="small"),
        },
        height=400
    )

    if missing_in_iss:
        st.warning(f"⚠ Тикеры не найдены в ISS: **{', '.join(missing_in_iss)}**.")
        # Диагностика: показываем похожие тикеры
        similar = [s for s in iss_df["SECID"].astype(str).str.upper().unique() if "SI" in s]
        if similar:
            st.caption(f"Похожие SECID в ISS: {', '.join(similar[:20])}")

    if ims_df is not None and not ims_df.empty and "IM_TIME" in ims_df.columns:
        ims_time = ims_df["IM_TIME"].max()
        if pd.notna(ims_time):
            st.caption(f"ГО рассчитано на: **{ims_time.strftime('%d.%m.%Y %H:%M')}** · Тип ГО: **{margin_type}**")
    else:
        st.caption(f"Тип ГО: **{margin_type}** · Данные IMS недоступны")
